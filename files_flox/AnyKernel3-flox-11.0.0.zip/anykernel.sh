# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=ElementalX-flox Kernel by kiraryu @ xda-developers
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=flox
device.name2=debx
device.name3=flo
device.name4=deb
#device.name5=
supported.versions= 10 - 11
#supported.patchlevels=
'; } # end properties

# shell variables
block=/dev/block/platform/msm_sdcc.1/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;


## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;


## AnyKernel install
dump_boot;

# begin ramdisk changes

# init.rc
#append_file fstab.flox "zram0" fstab;
# init.tuna.rc

# fstab.tuna

# OC
patch_cmdline l2_opt l2_opt=0;
patch_cmdline max_oc0 max_oc0=1836000;
patch_cmdline max_oc1 max_oc1=1836000;
patch_cmdline max_oc2 max_oc2=1836000;
patch_cmdline max_oc3 max_oc3=1836000;
patch_cmdline gpu_oc gpu_oc=1;

# end ramdisk changes

write_boot;
## end install

