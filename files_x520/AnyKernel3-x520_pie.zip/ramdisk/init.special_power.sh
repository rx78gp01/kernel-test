#!/system/bin/sh

################################################################################
# helper functions to allow Android init like script

function write() {
    echo -n $2 > $1
}

function copy() {
    cat $1 > $2
}

# macro to write pids to system-background cpuset
function writepid_sbg() {
    until [ ! "$1" ]; do
        echo -n $1 > /dev/cpuset/system-background/tasks;
        shift;
    done;
}

################################################################################

{

sleep 10;

# Little cluster
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/use_sched_load 0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay 0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load 100
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq 0
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/target_loads "70 1017600:50 1190400:65 1305600:80 1382400:90 1401600:95"
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/timer_rate 20000
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/min_sample_time 40000
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/ignore_hispeed_on_notif 1
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/max_freq_hysteresis 80000
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/timer_slack 30000
write /sys/devices/system/cpu/cpu0/cpufreq/interactive/io_is_busy 1

# big cluster
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/use_sched_load 0
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay "20000 1113600:40000 1612800:20000"
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load 85
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq 1113600
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/target_loads "90 1382400:95"
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/timer_rate 30000
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/min_sample_time 30000
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/ignore_hispeed_on_notif 1
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/max_freq_hysteresis 80000
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/timer_slack 30000
write /sys/devices/system/cpu/cpu4/cpufreq/interactive/io_is_busy 1

# cpu-boost
write /sys/module/cpu_boost/parameters/input_boost_freq "0:1190400 4:998400"
write /sys/module/cpu_boost/parameters/input_boost_ms 1500
write /sys/module/cpu_boost/parameters/input_boost_enabled 0

# set (super) packing parameters
write /sys/devices/system/cpu/cpu0/sched_mostly_idle_freq 0
write /sys/devices/system/cpu/cpu4/sched_mostly_idle_freq 0

# Setting b.L scheduler parameters
write /proc/sys/kernel/sched_boost 0
write /proc/sys/kernel/sched_migration_fixup 1
write /proc/sys/kernel/sched_upmigrate 95
write /proc/sys/kernel/sched_downmigrate 90
write /proc/sys/kernel/sched_freq_inc_notify 400000
write /proc/sys/kernel/sched_freq_dec_notify 400000
write /proc/sys/kernel/sched_spill_nr_run 3
write /proc/sys/kernel/sched_init_task_load 100

write /proc/sys/vm/min_free_kbytes 9645
write /sys/module/g_android/parameters/mtp_tx_req_len 131072
write /sys/module/g_android/parameters/mtp_rx_req_len 131072

}&
